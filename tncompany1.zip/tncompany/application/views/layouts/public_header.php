<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title : 'T&N Company'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo base_url(); ?>">
            <span class="text-primary">T</span>&<span class="text-danger">N</span> Company
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo base_url('home'); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo base_url('about'); ?>">About</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo base_url('jobs'); ?>">Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo base_url('contact'); ?>">Contact</a></li>
                <li class="nav-item ms-lg-3">
                    <a href="<?php echo base_url('signin'); ?>" class="btn btn-outline-primary px-4">Sign In</a>
                </li>
                <li class="nav-item ms-2">
                    <a href="<?php echo base_url('signup'); ?>" class="btn btn-primary px-4">Apply Now</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
