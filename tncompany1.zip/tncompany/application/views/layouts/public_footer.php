<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <h5 class="fw-bold mb-3"><span class="text-primary">T</span>&<span class="text-danger">N</span> Company</h5>
                <p class="text-white-50 mb-3">Modern Online Registration System for job applications.</p>
            </div>
            <div class="col-lg-2">
                <h6 class="fw-bold mb-3">Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url(); ?>" class="text-white-50 text-decoration-none mb-2 d-block">Home</a></li>
                    <li><a href="<?php echo base_url('about'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">About Us</a></li>
                    <li><a href="<?php echo base_url('jobs'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">Job Openings</a></li>
                    <li><a href="<?php echo base_url('contact'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">Contact</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h6 class="fw-bold mb-3">Support</h6>
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url('faq'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">FAQ</a></li>
                    <li><a href="<?php echo base_url('privacy'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">Privacy Policy</a></li>
                    <li><a href="<?php echo base_url('terms'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">Terms of Service</a></li>
                    <li><a href="<?php echo base_url('help'); ?>" class="text-white-50 text-decoration-none mb-2 d-block">Help Center</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h6 class="fw-bold mb-3">Contact Us</h6>
                <ul class="list-unstyled text-white-50">
                    <li class="mb-2"><i class="fas fa-envelope me-2"></i>support@tncompany.com</li>
                    <li class="mb-2"><i class="fas fa-phone me-2"></i>+63 912 345 6789</li>
                    <li class="mb-2"><i class="fas fa-map-marker-alt me-2"></i>Manila, Philippines</li>
                </ul>
            </div>
        </div>
        <hr class="border-secondary mt-4 mb-3">
        <div class="row">
            <div class="col-md-6 text-white-50 small">© 2026 T&N Company. All Rights Reserved.</div>
            <div class="col-md-6 text-md-end text-white-50 small">Developed by Famini & Pacalioga | BSIT 2C</div>
        </div>
    </div>
</footer>
<div class="toast-container-custom"></div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>
<?php if (isset($extra_js)) echo $extra_js; ?>
</body>
</html>
