<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - T&N Company</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<div class="container-fluid">
    <div class="row g-0" style="min-height:100vh">
        <div class="col-lg-6 d-none d-lg-block signin-gradient">
            <div class="d-flex flex-column justify-content-center align-items-center h-100 text-white p-5 text-center">
                <i class="fas fa-building mb-4" style="font-size:4rem;opacity:.8"></i>
                <h1 class="fw-bold mb-3">T&N ONLINE<br>REGISTRATION</h1>
                <p class="text-white-50 mb-4">Sign in to access your dashboard and manage your applications seamlessly.</p>
                <div class="row g-3 w-100" style="max-width:320px">
                    <div class="col-4"><div class="bg-white bg-opacity-10 rounded-3 p-3"><h3 class="fw-bold mb-0">32+</h3><p class="mb-0" style="font-size: 12px;">Applications</p></div></div>
                    <div class="col-4"><div class="bg-white bg-opacity-10 rounded-3 p-3"><h3 class="fw-bold mb-0">14+</h3><p class="small mb-0">Approved</p></div></div>
                    <div class="col-4"><div class="bg-white bg-opacity-10 rounded-3 p-3"><h3 class="fw-bold mb-0">3</h3><p class="small mb-0">Roles</p></div></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 d-flex align-items-center justify-content-center bg-light">
            <div class="p-4 p-md-5 w-100" style="max-width:460px">
                <div class="text-center mb-4">
                    <a href="<?php echo base_url(); ?>" class="text-decoration-none">
                        <h3 class="fw-bold"><span class="text-primary">T</span>&<span class="text-danger">N</span> Company</h3>
                    </a>
                    <p class="text-muted small">Choose your role and sign in</p>
                </div>
                <ul class="nav nav-pills nav-justified mb-4">
                    <li class="nav-item"><button class="nav-link active" style="font-size: 16px; padding: 10px 15px;" id="applicant-tab" data-bs-toggle="pill" data-bs-target="#t-app" type="button"><i class="fas fa-user me-1"></i>Applicant</button></li>
                    <li class="nav-item"><button class="nav-link" id="hr-tab" data-bs-toggle="pill" data-bs-target="#t-hr" type="button"><i class="fas fa-users me-1"></i>HR Staff</button></li>
                    <li class="nav-item"><button class="nav-link" id="admin-tab" data-bs-toggle="pill" data-bs-target="#t-adm" type="button"><i class="fas fa-shield-alt me-1"></i>Admin</button></li>
                </ul>
                <div class="tab-content mb-3">
                    <div class="tab-pane fade show active small text-muted" id="t-app"><i class="fas fa-info-circle text-primary me-1"></i>For job applicants applying to T&N positions.</div>
                    <div class="tab-pane fade small text-muted" id="t-hr"><i class="fas fa-info-circle text-primary me-1"></i>For authorized HR staff to review applications.</div>
                    <div class="tab-pane fade small text-muted" id="t-adm"><i class="fas fa-exclamation-circle text-danger me-1"></i>Restricted to system administrators only.</div>
                </div>
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <div class="mb-3"><label class="form-label small fw-medium">Email Address</label><input type="email" class="form-control" id="email" placeholder="Enter your email"></div>
                        <div class="mb-4"><label class="form-label small fw-medium">Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="password" placeholder="Enter password">
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword"><i class="fas fa-eye"></i></button>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary w-100 mb-3" id="signinBtn">
                            <i class="fas fa-sign-in-alt me-2"></i>Sign In
                        </button>
                        <div class="text-center"><p class="text-muted small mb-0">No account? <a href="<?php echo base_url('signup'); ?>" class="text-primary fw-medium">Sign up here</a></p></div>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <a href="<?php echo base_url(); ?>" class="text-muted text-decoration-none small"><i class="fas fa-arrow-left me-1"></i>Back to Home</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="toast-container-custom"></div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>
<script>
const SIGNIN_URL = '<?php echo base_url("signin"); ?>';
$('#togglePassword').on('click',function(){
    const p=$('#password'),i=$(this).find('i');
    p.attr('type',p.attr('type')==='password'?'text':'password');
    i.toggleClass('fa-eye fa-eye-slash');
});
function getRole(){
    if($('#hr-tab').hasClass('active')) return 'hr';
    if($('#admin-tab').hasClass('active')) return 'admin';
    return 'applicant';
}
$('#signinBtn').on('click',function(){
    const email=$('#email').val().trim(), password=$('#password').val(), role=getRole();
    if(!email||!password){showToast('Please fill in all fields.','warning');return;}
    $(this).prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-2"></span>Signing in...');
    $.ajax({
        url: SIGNIN_URL, method:'POST',
        data:{email,password,role},
        success:function(r){
            if(r.success){showToast('Login successful! Redirecting...','success');setTimeout(()=>window.location.href=r.data.redirect,800);}
            else{showToast(r.message,'error');$('#signinBtn').prop('disabled',false).html('<i class="fas fa-sign-in-alt me-2"></i>Sign In');}
        },
        error:function(){showToast('Server error.','error');$('#signinBtn').prop('disabled',false).html('<i class="fas fa-sign-in-alt me-2"></i>Sign In');}
    });
});
$('#email,#password').on('keypress',function(e){if(e.which===13)$('#signinBtn').trigger('click');});
</script>
</body>
</html>
