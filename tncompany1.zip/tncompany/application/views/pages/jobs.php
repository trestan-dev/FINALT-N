<?php $title = 'Job Openings - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center">
    <div class="container"><h1 class="fw-bold display-5">Open Positions</h1><p class="text-white-50 mt-2">Find your next career opportunity at T&N Company</p></div>
</div>
<div class="container pb-5">
    <div class="row mb-4 g-2">
        <div class="col-md-8"><input type="text" class="form-control" id="jobSearch" placeholder="Search position or department..."></div>
        <div class="col-md-4">
            <select class="form-select" id="deptF">
                <option value="">All Departments</option>
                <?php foreach($jobs as $j): ?>
                    <option><?php echo $j['department_name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div id="jobsList">
        <?php if(empty($jobs)): ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-briefcase fa-3x d-block mb-3"></i>
                <h5>No open positions at this time.</h5>
                <p>Check back soon for new openings.</p>
            </div>
        <?php else: ?>
            <?php foreach($jobs as $j): ?>
            <div class="job-card mb-3" data-title="<?php echo strtolower($j['title']); ?>" data-dept="<?php echo $j['department_name']; ?>">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <h4 class="fw-bold mb-1"><?php echo $j['title']; ?></h4>
                        <span class="dept-badge me-2"><?php echo $j['department_name']; ?></span>
                        <span class="badge bg-success bg-opacity-10 text-success">Open</span>
                    </div>
                    <a href="<?php echo base_url('signup'); ?>" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-2"></i>Apply Now
                    </a>
                </div>
                <p class="text-muted mt-3 mb-2"><?php echo $j['description'] ?: 'No description provided.'; ?></p>
                <div class="mb-2"><strong class="small">Requirements:</strong> <span class="text-muted small"><?php echo $j['requirements'] ?: '—'; ?></span></div>
                <div class="text-muted small"><i class="fas fa-calendar me-1"></i>Posted <?php echo date('M j, Y', strtotime($j['created_at'])); ?></div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
<script>
$('#jobSearch,#deptF').on('input change',function(){
    const s=$('#jobSearch').val().toLowerCase(),d=$('#deptF').val().toLowerCase();
    $('.job-card').each(function(){
        const t=$(this).data('title'),dp=$(this).data('dept').toLowerCase();
        $(this).toggle((!s||t.includes(s)||dp.includes(s))&&(!d||dp===d));
    });
});
</script>
