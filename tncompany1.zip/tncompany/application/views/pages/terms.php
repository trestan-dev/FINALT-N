<?php $title = 'Terms of Service - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center"><div class="container"><h1 class="fw-bold display-5">Terms of Service</h1><p class="text-white-50 mt-2">Please read these terms carefully.</p></div></div>
<div class="container pb-5">
    <h4 class="fw-bold mt-4 mb-3">1. Acceptance of Terms</h4>
    <p class="text-muted">By creating an account and using the T&N Company Online Registration System, you agree to be bound by these Terms of Service.</p>
    <h4 class="fw-bold mt-4 mb-3">2. Account Responsibility</h4>
    <p class="text-muted">You are responsible for maintaining the confidentiality of your account credentials and all activities that occur under your account.</p>
    <h4 class="fw-bold mt-4 mb-3">3. Applicant Responsibilities</h4>
    <p class="text-muted">Applicants must provide accurate and truthful information, submit only genuine documents, and not create multiple accounts.</p>
    <h4 class="fw-bold mt-4 mb-3">4. Prohibited Activities</h4>
    <p class="text-muted">Users may not submit false information, attempt to bypass system security, or access unauthorized areas of the system.</p>
    <h4 class="fw-bold mt-4 mb-3">5. Application Process</h4>
    <p class="text-muted">Submission of an application does not guarantee employment. T&N Company reserves the right to accept or reject any application at its discretion.</p>
    <h4 class="fw-bold mt-4 mb-3">6. Contact</h4>
    <p class="text-muted">Questions: <a href="mailto:legal@tncompany.com">legal@tncompany.com</a></p>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
