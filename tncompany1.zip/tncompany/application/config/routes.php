<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// ── Default ──────────────────────────────────────────────────────────────────
$route['default_controller'] = 'Home';
$route['404_override']       = '';
$route['translate_uri_dashes'] = FALSE;

// ── Public pages ─────────────────────────────────────────────────────────────
$route['about']   = 'Home/about';
$route['jobs']    = 'Home/jobs';
$route['contact'] = 'Home/contact';
$route['faq']     = 'Home/faq';
$route['help']    = 'Home/help';
$route['privacy'] = 'Home/privacy';
$route['terms']   = 'Home/terms';

// ── Auth ──────────────────────────────────────────────────────────────────────
$route['signin']['GET']  = 'Auth/signin_page';
$route['signin']['POST'] = 'Auth/signin';
$route['signup']['GET']  = 'Auth/signup_page';
$route['signup']['POST'] = 'Auth/signup';
$route['signout']        = 'Auth/signout';

// ── Applicant ─────────────────────────────────────────────────────────────────
$route['applicant']                    = 'Applicant/index';
$route['applicant/api/stats']          = 'Applicant/api_stats';
$route['applicant/api/applications']   = 'Applicant/api_applications';
$route['applicant/api/jobs']           = 'Applicant/api_jobs';
$route['applicant/api/apply']          = 'Applicant/api_apply';
$route['applicant/api/profile']        = 'Applicant/api_profile';

// ── HR ────────────────────────────────────────────────────────────────────────
$route['hr']                           = 'Hr/index';
$route['hr/api/stats']                 = 'Hr/api_stats';
$route['hr/api/applications']          = 'Hr/api_applications';
$route['hr/api/jobs']                  = 'Hr/api_jobs';
$route['hr/api/review']                = 'Hr/api_review';
$route['hr/api/job/save']              = 'Hr/api_job_save';
$route['hr/api/job/delete']            = 'Hr/api_job_delete';
$route['hr/api/audit']                 = 'Hr/api_audit';

// ── Admin ─────────────────────────────────────────────────────────────────────
$route['admin']                        = 'Admin/index';
$route['admin/api/stats']              = 'Admin/api_stats';
$route['admin/api/applications']       = 'Admin/api_applications';
$route['admin/api/jobs']               = 'Admin/api_jobs';
$route['admin/api/job/save']           = 'Admin/api_job_save';
$route['admin/api/job/delete']         = 'Admin/api_job_delete';
$route['admin/api/hr-accounts']        = 'Admin/api_hr_accounts';
$route['admin/api/hr/create']          = 'Admin/api_hr_create';
$route['admin/api/hr/toggle']          = 'Admin/api_hr_toggle';
$route['admin/api/hr/delete']          = 'Admin/api_hr_delete';
$route['admin/api/users']              = 'Admin/api_users';
$route['admin/api/audit']              = 'Admin/api_audit';
