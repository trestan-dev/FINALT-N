<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[AllowDynamicProperties]
class Auth extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Audit_model');
    }

    public function signin_page() {
        $user = $this->session_user();
        if ($user) { redirect($user['role']); return; }
        $this->load->view('auth/signin');
    }

    public function signin() {
        $email    = strtolower(trim($this->input->post('email')));
        $password = $this->input->post('password');
        $role     = $this->input->post('role');

        if (!$email || !$password || !in_array($role, ['applicant','hr','admin'])) {
            json_error('Invalid input.');
        }

        $user = $this->User_model->find_by_email_and_role($email, $role);

        if (!$user || $user['password'] !== $password) {
            json_error('Invalid credentials or role.');
        }
        if ($user['status'] === 'suspended') {
            json_error('Account suspended. Contact admin.');
        }

        $this->set_session($user);
        $this->Audit_model->add_log($user['id'], 'login',
            trim($user['first_name'].' '.$user['last_name']).' ('.$role.') logged in.');

        $redirect = base_url($role);
        json_success(['redirect' => $redirect], 'Login successful!');
    }

    public function signup_page() {
        $this->load->view('auth/signup');
    }

    public function signup() {
        $post = $this->input->post();

        $required = ['first_name','last_name','dob','gender','phone','email','address','password'];
        foreach ($required as $f) {
            if (empty($post[$f])) json_error('Fill in all required fields.');
        }

        $email = strtolower(trim($post['email']));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_error('Invalid email address.');
        if ($this->User_model->email_exists($email)) json_error('Email already registered.');
        if (strlen($post['password']) < 6) json_error('Password must be at least 6 characters.');
        if ($post['password'] !== $post['confirm_password']) json_error('Passwords do not match.');

        $id = $this->User_model->create([
            'email'      => $email,
            'password'   => $post['password'],
            'role'       => 'applicant',
            'first_name' => trim($post['first_name']),
            'last_name'  => trim($post['last_name']),
            'phone'      => $post['phone'],
            'address'    => $post['address'],
            'dob'        => $post['dob'],
            'gender'     => $post['gender'],
            'status'     => 'active',
        ]);

        $this->Audit_model->add_log($id, 'account_created',
            'New applicant: '.$post['first_name'].' '.$post['last_name'].' ('.$email.')');

        json_success([], 'Account created! Redirecting to sign in...');
    }

    public function signout() {
        $user = $this->session_user();
        if ($user) {
            $this->load->model('Audit_model');
            $this->Audit_model->add_log($user['id'], 'logout', $user['name'].' logged out.');
        }
        $this->session->sess_destroy();
        redirect('signin');
    }
}
