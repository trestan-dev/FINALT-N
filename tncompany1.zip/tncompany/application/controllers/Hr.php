<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[AllowDynamicProperties]
class Hr extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(['Application_model','Job_model','Audit_model']);
    }

    public function index() {
        $user = require_auth('hr');
        $this->Audit_model->add_log($user['id'], 'page_view', 'HR viewed dashboard.');
        $this->load->view('hr/dashboard', ['user' => $user]);
    }

    public function api_stats() {
        require_auth('hr');
        json_success($this->Application_model->get_status_counts());
    }

    public function api_applications() {
        require_auth('hr');
        $apps = $this->Application_model->get_all_with_applicant();
        foreach ($apps as &$a) {
            $a['submitted_fmt']   = fmt_date($a['created_at']);
            $a['reviewed_at_fmt'] = fmt_date($a['reviewed_at']);
            $a['resume_url']      = $a['resume_path']
                ? base_url('assets/uploads/resumes/'.$a['resume_path']) : null;
        }
        json_success($apps);
    }

    public function api_jobs() {
        require_auth('hr');
        $jobs = $this->Job_model->get_all_with_dept();
        foreach ($jobs as &$j) $j['created_fmt'] = fmt_date($j['created_at']);
        json_success($jobs);
    }

    public function api_review() {
        $user     = require_auth('hr');
        $app_code = $this->input->post('app_code');
        $status   = $this->input->post('status');
        $notes    = $this->input->post('review_notes');

        if (!in_array($status, ['pending','review','approved','rejected'])) json_error('Invalid status.');

        $app = $this->Application_model->get_by_code($app_code);
        if (!$app) json_error('Application not found.');

        $old = $app['status'];
        $this->Application_model->update_app($app['id'], [
            'status'       => $status,
            'review_notes' => $notes,
            'reviewed_by'  => $user['id'],
            'reviewed_at'  => date('Y-m-d H:i:s'),
        ]);
        $this->Audit_model->add_log($user['id'], 'status_update',
            'App '.$app_code.' changed from '.$old.' to '.$status.' by '.$user['name'].'.');

        json_success([], 'Application '.$app_code.' updated to "'.$status.'".');
    }

    public function api_job_save() {
        $user   = require_auth('hr');
        $id     = (int)$this->input->post('id');
        $title  = trim($this->input->post('title'));
        $dept   = (int)$this->input->post('department_id');
        $desc   = $this->input->post('description');
        $req    = $this->input->post('requirements');

        if (!$title || !$dept) json_error('Title and department are required.');

        $data = ['title'=>$title,'department_id'=>$dept,'description'=>$desc,'requirements'=>$req];

        if ($id) {
            $this->Job_model->update_job($id, $data);
            $this->Audit_model->add_log($user['id'], 'job_update', 'Job "'.$title.'" updated by '.$user['name'].'.');
            json_success([], 'Job updated!');
        } else {
            $data['status'] = 'open';
            $this->Job_model->create($data);
            $this->Audit_model->add_log($user['id'], 'job_post', 'New job "'.$title.'" posted by '.$user['name'].'.');
            json_success([], 'Job posted!');
        }
    }

    public function api_job_delete() {
        $user = require_auth('hr');
        $id   = (int)$this->input->post('id');
        $job  = $this->Job_model->find_by_id($id);
        if (!$job) json_error('Job not found.');
        $this->Job_model->delete_job($id);
        $this->Audit_model->add_log($user['id'], 'job_delete', 'Job "'.$job['title'].'" deleted by '.$user['name'].'.');
        json_success([], 'Job deleted.');
    }

        public function api_audit() {
        require_auth('hr');
        $logs = $this->Audit_model->get_logs_with_user(100);
        json_success($logs);
    }
}
