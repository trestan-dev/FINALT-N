<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[AllowDynamicProperties]
class Admin extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(['Application_model','Job_model','User_model','Audit_model']);
    }

    public function index() {
        $user = require_auth('admin');
        $this->Audit_model->add_log($user['id'], 'page_view', 'Admin viewed dashboard.');
        $this->load->view('admin/dashboard', ['user' => $user]);
    }

    public function api_stats() {
        require_auth('admin');
        $counts = $this->Application_model->get_status_counts();
        $recent = $this->Application_model->get_recent(5);
        foreach ($recent as &$r) $r['submitted_fmt'] = fmt_date($r['created_at']);
        json_success([
            'counts'    => $counts,
            'userCount' => $this->User_model->count_all(),
            'openJobs'  => $this->Job_model->get_open_count(),
            'recent'    => $recent,
        ]);
    }

    public function api_applications() {
        require_auth('admin');
        $apps = $this->Application_model->get_all_with_applicant();
        foreach ($apps as &$a) {
            $a['submitted_fmt'] = fmt_date($a['created_at']);
            $a['resume_url']    = $a['resume_path']
                ? base_url('assets/uploads/resumes/'.$a['resume_path']) : null;
        }
        json_success($apps);
    }

    public function api_jobs() {
        require_auth('admin');
        $jobs = $this->Job_model->get_all_with_dept();
        foreach ($jobs as &$j) $j['created_fmt'] = fmt_date($j['created_at']);
        json_success($jobs);
    }

    public function api_job_save() {
        $user   = require_auth('admin');
        $id     = (int)$this->input->post('id');
        $title  = trim($this->input->post('title'));
        $dept   = (int)$this->input->post('department_id');
        $desc   = $this->input->post('description');
        $req    = $this->input->post('requirements');
        $status = $this->input->post('status') ?: 'open';

        if (!$title || !$dept) json_error('Title and department required.');

        $data = ['title'=>$title,'department_id'=>$dept,'description'=>$desc,'requirements'=>$req,'status'=>$status];

        if ($id) {
            $this->Job_model->update_job($id, $data);
            $this->Audit_model->add_log($user['id'], 'job_update', 'Job "'.$title.'" updated by admin.');
            json_success([], 'Job updated!');
        } else {
            $this->Job_model->create($data);
            $this->Audit_model->add_log($user['id'], 'job_post', 'New job "'.$title.'" posted by admin.');
            json_success([], 'Job posted!');
        }
    }

    public function api_job_delete() {
        $user = require_auth('admin');
        $id   = (int)$this->input->post('id');
        $job  = $this->Job_model->find_by_id($id);
        if (!$job) json_error('Not found.');
        $this->Job_model->delete_job($id);
        $this->Audit_model->add_log($user['id'], 'job_delete', 'Job "'.$job['title'].'" deleted by admin.');
        json_success([], 'Job deleted.');
    }

    public function api_hr_accounts() {
        require_auth('admin');
        $hrs = $this->User_model->get_all_hr();
        foreach ($hrs as &$u) {
            $u['full_name']   = trim($u['first_name'].' '.$u['last_name']);
            $u['created_fmt'] = fmt_date($u['created_at']);
        }
        json_success($hrs);
    }

    public function api_hr_create() {
        $user  = require_auth('admin');
        $name  = trim($this->input->post('name'));
        $email = strtolower(trim($this->input->post('email')));
        $pw    = $this->input->post('password');
        $dept  = $this->input->post('department');

        if (!$name||!$email||!$pw||!$dept) json_error('Fill all fields.');
        if ($this->User_model->email_exists($email)) json_error('Email already exists.');
        if (strlen($pw) < 6) json_error('Password must be at least 6 characters.');

        $parts = explode(' ', $name, 2);
        $id = $this->User_model->create([
            'email'      => $email,
            'password'   => $pw,
            'role'       => 'hr',
            'first_name' => $parts[0],
            'last_name'  => isset($parts[1]) ? $parts[1] : '',
            'address'    => $dept,
            'status'     => 'active',
        ]);
        $this->Audit_model->add_log($user['id'], 'account_created',
            'Admin created HR account: '.$name.' ('.$email.')');
        json_success(['id'=>$id], 'HR account for '.$name.' created!');
    }

    public function api_hr_toggle() {
        $user   = require_auth('admin');
        $id     = (int)$this->input->post('id');
        $target = $this->User_model->find_by_id($id);
        if (!$target || $target['role'] !== 'hr') json_error('Not found.');
        $new_status = $target['status'] === 'active' ? 'suspended' : 'active';
        $this->User_model->update_user($id, ['status' => $new_status]);
        $this->Audit_model->add_log($user['id'], 'account_update',
            'HR '.$target['first_name'].' status: '.$new_status.'.');
        json_success(['status'=>$new_status], 'Account '.$new_status.'.');
    }

    public function api_hr_delete() {
        $user   = require_auth('admin');
        $id     = (int)$this->input->post('id');
        $target = $this->User_model->find_by_id($id);
        if (!$target || $target['role'] !== 'hr') json_error('Not found.');
        $this->User_model->delete_user($id);
        $this->Audit_model->add_log($user['id'], 'account_delete',
            'HR account '.$target['first_name'].' '.$target['last_name'].' deleted.');
        json_success([], 'HR account deleted.');
    }

    public function api_users() {
        require_auth('admin');
        $users = $this->User_model->get_all_users();
        foreach ($users as &$u) {
            $u['full_name']   = trim($u['first_name'].' '.$u['last_name']);
            $u['created_fmt'] = fmt_date($u['created_at']);
            unset($u['password']);
        }
        json_success($users);
    }

        public function api_audit() {
        require_auth('admin');
        $search = $this->input->get('search');
        $action = $this->input->get('action');
        $logs   = $this->Audit_model->get_logs_with_user(500, $search, $action);
        json_success($logs);
    }
}
