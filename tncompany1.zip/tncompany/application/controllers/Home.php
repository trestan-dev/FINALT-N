<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[AllowDynamicProperties]
class Home extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Job_model');
    }

    public function index() {
        $this->load->view('pages/home');
    }

    public function about()   { $this->load->view('pages/about'); }
    public function contact() { $this->load->view('pages/contact'); }
    public function faq()     { $this->load->view('pages/faq'); }
    public function help()    { $this->load->view('pages/help'); }
    public function privacy() { $this->load->view('pages/privacy'); }
    public function terms()   { $this->load->view('pages/terms'); }

    public function jobs() {
        $data['jobs'] = $this->Job_model->get_open_with_dept();
        $this->load->view('pages/jobs', $data);
    }
}
