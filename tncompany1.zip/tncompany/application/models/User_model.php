<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function find_by_email_and_role($email, $role) {
        return $this->db->where('email', $email)
                        ->where('role', $role)
                        ->get('users')->row_array();
    }

    public function email_exists($email, $exclude_id = 0) {
        $this->db->where('email', $email);
        if ($exclude_id) $this->db->where('id !=', $exclude_id);
        return $this->db->count_all_results('users') > 0;
    }

    public function get_all_hr($search = '') {
        $this->db->where('role', 'hr');
        if ($search) $this->db->like('first_name', $search)->or_like('last_name', $search)->or_like('email', $search);
        return $this->db->get('users')->result_array();
    }

    public function get_all_users() {
        return $this->db->order_by('created_at', 'DESC')->get('users')->result_array();
    }

    public function create($data) {
        $this->db->insert('users', $data);
        return $this->db->insert_id();
    }

    public function update_user($id, $data) {
        $this->db->where('id', $id)->update('users', $data);
    }

    public function delete_user($id) {
        $this->db->where('id', $id)->delete('users');
    }

    public function find_by_id($id) {
        return $this->db->where('id', $id)->get('users')->row_array();
    }

    public function count_all() {
        return $this->db->count_all('users');
    }

    public function full_name($user) {
        return trim($user['first_name'] . ' ' . $user['last_name']);
    }
}
