<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Application_model extends CI_Model {

    public function get_all_with_applicant() {
        return $this->db->select('a.*, CONCAT(u.first_name," ",u.last_name) as applicant_name, u.email, u.phone, CONCAT(r.first_name," ",r.last_name) as reviewer_name')
            ->from('applications a')
            ->join('users u', 'u.id = a.applicant_id', 'left')
            ->join('users r', 'r.id = a.reviewed_by', 'left')
            ->order_by('a.created_at', 'DESC')
            ->get()->result_array();
    }

    public function get_for_applicant($user_id) {
        return $this->db->select('a.*, CONCAT(r.first_name," ",r.last_name) as reviewer_name')
            ->from('applications a')
            ->join('users r', 'r.id = a.reviewed_by', 'left')
            ->where('a.applicant_id', $user_id)
            ->order_by('a.created_at', 'DESC')
            ->get()->result_array();
    }

    public function get_status_counts() {
        $rows = $this->db->select('status, COUNT(*) as cnt')
            ->group_by('status')
            ->get('applications')->result_array();
        $counts = ['total'=>0,'pending'=>0,'review'=>0,'approved'=>0,'rejected'=>0];
        foreach ($rows as $r) {
            $counts[$r['status']] = (int)$r['cnt'];
            $counts['total'] += (int)$r['cnt'];
        }
        return $counts;
    }

    public function get_status_counts_for_applicant($user_id) {
        $rows = $this->db->select('status, COUNT(*) as cnt')
            ->where('applicant_id', $user_id)
            ->group_by('status')
            ->get('applications')->result_array();
        $counts = ['total'=>0,'pending'=>0,'review'=>0,'approved'=>0,'rejected'=>0];
        foreach ($rows as $r) {
            $counts[$r['status']] = (int)$r['cnt'];
            $counts['total'] += (int)$r['cnt'];
        }
        return $counts;
    }

    public function get_by_code($code) {
        return $this->db->where('app_code', $code)->get('applications')->row_array();
    }

    public function has_applied($user_id, $position) {
        return $this->db->where('applicant_id', $user_id)
                        ->where('position', $position)
                        ->count_all_results('applications') > 0;
    }

    public function create($data) {
        $this->db->insert('applications', $data);
        return $this->db->insert_id();
    }

    public function update_app($id, $data) {
        $this->db->where('id', $id)->update('applications', $data);
    }

    public function count_all() {
        return $this->db->count_all('applications');
    }

    public function get_recent($limit = 5) {
        return $this->db->select('a.*, CONCAT(u.first_name," ",u.last_name) as applicant_name')
            ->from('applications a')
            ->join('users u', 'u.id = a.applicant_id', 'left')
            ->order_by('a.created_at', 'DESC')
            ->limit($limit)
            ->get()->result_array();
    }
}
