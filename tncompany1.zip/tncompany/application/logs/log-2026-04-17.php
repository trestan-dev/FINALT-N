<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "phone" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 93
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 93
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "address" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 94
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 94
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "qualifications" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 95
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 95
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "education" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 96
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 96
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "phone" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 93
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 93
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "address" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 94
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 94
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "qualifications" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 95
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 95
ERROR - 2026-04-17 06:27:59 --> Severity: Warning --> Undefined array key "education" C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 96
ERROR - 2026-04-17 06:27:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\tncompany\application\views\applicant\dashboard.php 96
ERROR - 2026-04-17 06:29:10 --> Query error: Unknown column 'qualifications' in 'field list' - Invalid query: UPDATE `users` SET `first_name` = 'Miss Almeda', `last_name` = 'Almeda', `phone` = '', `address` = '', `qualifications` = '', `education` = ''
WHERE `id` = '7'
